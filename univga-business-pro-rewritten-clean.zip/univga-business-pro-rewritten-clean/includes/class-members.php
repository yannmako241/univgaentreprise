<?php

/**
 * Organization members management
 */
class UNIVGA_Members {
    
    /**
     * Add member to organization/team
     */
    public static function add_member($org_id, $team_id, $user_id, $status = 'active') {
        global $wpdb;
        
        // Check if member already exists
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}univga_org_members WHERE org_id = %d AND user_id = %d",
            $org_id, $user_id
        ));
        
        if ($existing) {
            // Update existing membership
            return $wpdb->update(
                $wpdb->prefix . 'univga_org_members',
                array(
                    'team_id' => $team_id,
                    'status' => $status,
                    'removed_at' => null,
                ),
                array('id' => $existing->id),
                array('%d', '%s', '%s'),
                array('%d')
            ) !== false;
        }
        
        // Create new membership
        $result = $wpdb->insert(
            $wpdb->prefix . 'univga_org_members',
            array(
                'org_id' => intval($org_id),
                'team_id' => $team_id ? intval($team_id) : null,
                'user_id' => intval($user_id),
                'status' => $status,
            ),
            array('%d', '%d', '%d', '%s')
        );
        
        if ($result !== false && $status === 'active') {
            // Auto-enroll in organization courses
            self::auto_enroll_member($org_id, $team_id, $user_id);
        }
        
        return $result !== false;
    }
    
    /**
     * Remove member from organization
     */
    public static function remove_member($org_id, $user_id, $allow_replace = false) {
        global $wpdb;
        
        $result = $wpdb->update(
            $wpdb->prefix . 'univga_org_members',
            array(
                'status' => 'removed',
                'removed_at' => current_time('mysql'),
            ),
            array(
                'org_id' => $org_id,
                'user_id' => $user_id,
            ),
            array('%s', '%s'),
            array('%d', '%d')
        );
        
        if ($result !== false && $allow_replace) {
            // Release seat if replacement is allowed
            self::release_member_seats($org_id, $user_id);
        }
        
        return $result !== false;
    }
    
    /**
     * Get user's organization membership
     */
    public static function get_user_org_membership($user_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}univga_org_members WHERE user_id = %d AND status = 'active'",
            $user_id
        ));
    }
    
    /**
     * Get organization members
     */
    public static function get_org_members($org_id, $args = array()) {
        global $wpdb;
        
        $defaults = array(
            'team_id' => null,
            'status' => 'active',
            'limit' => null,
            'offset' => 0,
            'search' => '',
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('m.org_id = %d');
        $values = array($org_id);
        
        if ($args['team_id']) {
            $where[] = 'm.team_id = %d';
            $values[] = $args['team_id'];
        }
        
        if ($args['status']) {
            $where[] = 'm.status = %s';
            $values[] = $args['status'];
        }
        
        if ($args['search']) {
            $where[] = '(u.display_name LIKE %s OR u.user_email LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $values[] = $search_term;
            $values[] = $search_term;
        }
        
        $sql = "SELECT m.*, u.display_name, u.user_email, u.user_registered, t.name as team_name
                FROM {$wpdb->prefix}univga_org_members m
                JOIN {$wpdb->users} u ON m.user_id = u.ID
                LEFT JOIN {$wpdb->prefix}univga_teams t ON m.team_id = t.id
                WHERE " . implode(' AND ', $where);
        
        $sql .= " ORDER BY u.display_name ASC";
        
        if ($args['limit']) {
            $sql .= $wpdb->prepare(" LIMIT %d OFFSET %d", $args['limit'], $args['offset']);
        }
        
        return $wpdb->get_results($wpdb->prepare($sql, $values));
    }
    
    /**
     * Get organization members count
     */
    public static function get_org_members_count($org_id, $args = array()) {
        global $wpdb;
        
        $where = array('m.org_id = %d');
        $values = array($org_id);
        
        if (isset($args['team_id']) && $args['team_id']) {
            $where[] = 'm.team_id = %d';
            $values[] = $args['team_id'];
        }
        
        if (isset($args['status']) && $args['status']) {
            $where[] = 'm.status = %s';
            $values[] = $args['status'];
        }
        
        if (isset($args['search']) && $args['search']) {
            $where[] = '(u.display_name LIKE %s OR u.user_email LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $values[] = $search_term;
            $values[] = $search_term;
        }
        
        $sql = "SELECT COUNT(*)
                FROM {$wpdb->prefix}univga_org_members m
                JOIN {$wpdb->users} u ON m.user_id = u.ID
                WHERE " . implode(' AND ', $where);
        
        return (int) $wpdb->get_var($wpdb->prepare($sql, $values));
    }
    
    /**
     * Auto-enroll member in organization courses
     */
    private static function auto_enroll_member($org_id, $team_id, $user_id) {
        // Get active seat pools for this org/team
        $pools = UNIVGA_Seat_Pools::get_by_org($org_id, array(
            'team_id' => $team_id,
            'active_only' => true,
            'auto_enroll' => true,
        ));
        
        foreach ($pools as $pool) {
            // Check if pool has available seats
            if ($pool->seats_used >= $pool->seats_total) {
                continue;
            }
            
            // Get courses from pool scope
            $course_ids = UNIVGA_Seat_Pools::get_pool_courses($pool);
            
            foreach ($course_ids as $course_id) {
                // Enroll user in course
                UNIVGA_Tutor::enroll($user_id, $course_id, 'org');
            }
            
            // Consume seat
            UNIVGA_Seat_Pools::consume_seat($pool->id, $user_id);
        }
    }
    
    /**
     * Release member seats when removed
     */
    private static function release_member_seats($org_id, $user_id) {
        global $wpdb;
        
        // Get pools where user consumed seats
        $events = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT e.pool_id, p.allow_replace
             FROM {$wpdb->prefix}univga_seat_events e
             JOIN {$wpdb->prefix}univga_seat_pools p ON e.pool_id = p.id
             WHERE e.user_id = %d AND e.type = 'consume' AND p.org_id = %d",
            $user_id, $org_id
        ));
        
        foreach ($events as $event) {
            if ($event->allow_replace) {
                UNIVGA_Seat_Pools::release_seat($event->pool_id, $user_id);
            }
        }
    }
}
