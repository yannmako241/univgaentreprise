<?php

/**
 * REST API endpoints
 */
class UNIVGA_REST {
    
    public static function init() {
        register_rest_route('univga/v1', '/organizations/(?P<id>\d+)/dashboard', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_org_dashboard'),
            'permission_callback' => array(__CLASS__, 'check_org_permission'),
        ));
        
        register_rest_route('univga/v1', '/organizations/(?P<id>\d+)/members', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_org_members'),
            'permission_callback' => array(__CLASS__, 'check_org_permission'),
        ));
        
        register_rest_route('univga/v1', '/organizations/(?P<id>\d+)/invite', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'send_invitation'),
            'permission_callback' => array(__CLASS__, 'check_org_permission'),
        ));
        
        register_rest_route('univga/v1', '/organizations/(?P<id>\d+)/members/(?P<user_id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array(__CLASS__, 'remove_member'),
            'permission_callback' => array(__CLASS__, 'check_org_permission'),
        ));
    }
    
    /**
     * Check organization permission
     */
    public static function check_org_permission($request) {
        $org_id = $request->get_param('id');
        $user_id = get_current_user_id();
        
        if (!$user_id) {
            return false;
        }
        
        return UNIVGA_Capabilities::can_manage_org($user_id, $org_id);
    }
    
    /**
     * Get organization dashboard data
     */
    public static function get_org_dashboard($request) {
        $org_id = $request->get_param('id');
        
        $kpis = UNIVGA_Reports::get_org_dashboard_kpis($org_id);
        $org = UNIVGA_Orgs::get($org_id);
        
        return rest_ensure_response(array(
            'organization' => $org,
            'kpis' => $kpis,
        ));
    }
    
    /**
     * Get organization members
     */
    public static function get_org_members($request) {
        $org_id = $request->get_param('id');
        $page = $request->get_param('page') ?: 1;
        $per_page = $request->get_param('per_page') ?: 20;
        $search = $request->get_param('search') ?: '';
        $team_id = $request->get_param('team_id') ?: null;
        
        $args = array(
            'team_id' => $team_id,
            'search' => $search,
            'limit' => $per_page,
            'offset' => ($page - 1) * $per_page,
        );
        
        $members = UNIVGA_Reports::get_org_member_report($org_id, $args);
        $total = UNIVGA_Members::get_org_members_count($org_id, $args);
        
        $response = rest_ensure_response($members);
        $response->header('X-Total-Count', $total);
        $response->header('X-Total-Pages', ceil($total / $per_page));
        
        return $response;
    }
    
    /**
     * Send invitation
     */
    public static function send_invitation($request) {
        $org_id = $request->get_param('id');
        $email = $request->get_param('email');
        $team_id = $request->get_param('team_id');
        
        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'Invalid email address', array('status' => 400));
        }
        
        $result = UNIVGA_Invitations::send_invitation($org_id, $team_id, $email, get_current_user_id());
        
        if (is_wp_error($result)) {
            return new WP_Error($result->get_error_code(), $result->get_error_message(), array('status' => 400));
        }
        
        return rest_ensure_response(array(
            'message' => 'Invitation sent successfully',
        ));
    }
    
    /**
     * Remove organization member
     */
    public static function remove_member($request) {
        $org_id = $request->get_param('id');
        $user_id = $request->get_param('user_id');
        $allow_replace = $request->get_param('allow_replace') === true;
        
        $result = UNIVGA_Members::remove_member($org_id, $user_id, $allow_replace);
        
        if (!$result) {
            return new WP_Error('remove_failed', 'Failed to remove member', array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'message' => 'Member removed successfully',
        ));
    }
}
