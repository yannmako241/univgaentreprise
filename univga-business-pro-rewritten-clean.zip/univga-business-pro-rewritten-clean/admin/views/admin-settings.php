<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['submit'])) {
    check_admin_referer('univga_settings');
    
    // Save settings
    update_option('univga_default_allow_replace', isset($_POST['default_allow_replace']) ? 1 : 0);
    update_option('univga_debug_mode', isset($_POST['debug_mode']) ? 1 : 0);
    update_option('univga_dashboard_page_id', intval($_POST['dashboard_page_id']));
    update_option('univga_invitation_expire_days', intval($_POST['invitation_expire_days']));
    update_option('univga_remove_data_on_uninstall', isset($_POST['univga_remove_data_on_uninstall']) ? 1 : 0);
    
    echo '<div class="notice notice-success is-dismissible"><p>' . __('Paramètres sauvegardés avec succès.', UNIVGA_TEXT_DOMAIN) . '</p></div>';
}

// Get current settings
$default_allow_replace = get_option('univga_default_allow_replace', 0);
$debug_mode = get_option('univga_debug_mode', 0);
$dashboard_page_id = get_option('univga_dashboard_page_id', 0);
$invitation_expire_days = get_option('univga_invitation_expire_days', 7);

// Get cron status
$last_cron = get_option('univga_last_cron_summary', array());
$next_cron = wp_next_scheduled('univga_org_resync');
?>

<div class="wrap">
    <h1><?php _e('Paramètres UNIVGA', UNIVGA_TEXT_DOMAIN); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('univga_settings'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Paramètres par Défaut', UNIVGA_TEXT_DOMAIN); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" name="default_allow_replace" value="1" <?php checked($default_allow_replace); ?>>
                            <?php _e('Permettre le remplacement des sièges par défaut', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                        <p class="description"><?php _e('Quand activé, la suppression d\'un membre libère son siège pour réutilisation', UNIVGA_TEXT_DOMAIN); ?></p>
                    </fieldset>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="dashboard_page_id"><?php _e('Page du Tableau de Bord', UNIVGA_TEXT_DOMAIN); ?></label>
                </th>
                <td>
                    <?php
                    wp_dropdown_pages(array(
                        'name' => 'dashboard_page_id',
                        'id' => 'dashboard_page_id',
                        'selected' => $dashboard_page_id,
                        'show_option_none' => __('Sélectionner une page...', UNIVGA_TEXT_DOMAIN),
                        'option_none_value' => 0,
                    ));
                    ?>
                    <p class="description">
                        <?php _e('Page où les gestionnaires d\'organisation accèderont à leur tableau de bord. Ajoutez le shortcode [univga_org_dashboard] à cette page.', UNIVGA_TEXT_DOMAIN); ?>
                    </p>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="invitation_expire_days"><?php _e('Expiration des Invitations', UNIVGA_TEXT_DOMAIN); ?></label>
                </th>
                <td>
                    <input type="number" name="invitation_expire_days" id="invitation_expire_days" 
                           value="<?php echo $invitation_expire_days; ?>" min="1" max="30" class="small-text">
                    <?php _e('jours', UNIVGA_TEXT_DOMAIN); ?>
                    <p class="description"><?php _e('Nombre de jours avant expiration des liens d\'invitation', UNIVGA_TEXT_DOMAIN); ?></p>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><?php _e('Mode Debug', UNIVGA_TEXT_DOMAIN); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" name="debug_mode" value="1" <?php checked($debug_mode); ?>>
                            <?php _e('Activer les logs de débogage', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                        <p class="description"><?php _e('Enregistre des informations détaillées pour le dépannage. Consultez vos logs d\'erreurs.', UNIVGA_TEXT_DOMAIN); ?></p>
                    </fieldset>
                </td>
            </tr>
        </table>
        
        <h2><?php _e('Statut des Tâches Automatiques', UNIVGA_TEXT_DOMAIN); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Prochaine Synchronisation', UNIVGA_TEXT_DOMAIN); ?></th>
                <td>
                    <?php
                    if ($next_cron) {
                        echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $next_cron);
                    } else {
                        echo '<span style="color: #d63384;">' . __('Not scheduled', UNIVGA_TEXT_DOMAIN) . '</span>';
                    }
                    ?>
                    
                    <p>
                        <a href="<?php echo wp_nonce_url(add_query_arg('action', 'manual_resync'), 'manual_resync'); ?>" 
                           class="button-secondary"
                           onclick="return confirm('<?php _e('This will resync all organization data. Continue?', UNIVGA_TEXT_DOMAIN); ?>')">
                            <?php _e('Trigger Manual Resync', UNIVGA_TEXT_DOMAIN); ?>
                        </a>
                    </p>
                </td>
            </tr>
            
            <?php if (!empty($last_cron)): ?>
            <tr>
                <th scope="row"><?php _e('Last Sync Results', UNIVGA_TEXT_DOMAIN); ?></th>
                <td>
                    <ul>
                        <li><?php printf(__('Organizations processed: %d', UNIVGA_TEXT_DOMAIN), $last_cron['processed_orgs']); ?></li>
                        <li><?php printf(__('Expired pools: %d', UNIVGA_TEXT_DOMAIN), $last_cron['expired_pools']); ?></li>
                        <li><?php printf(__('Warnings sent: %d', UNIVGA_TEXT_DOMAIN), $last_cron['warnings_sent']); ?></li>
                        <li><?php printf(__('Errors: %d', UNIVGA_TEXT_DOMAIN), $last_cron['errors']); ?></li>
                        <li><?php printf(__('Duration: %d seconds', UNIVGA_TEXT_DOMAIN), $last_cron['duration']); ?></li>
                    </ul>
                </td>
            </tr>
            <?php endif; ?>
        </table>
        
        <h2><?php _e('Options de Désinstallation', UNIVGA_TEXT_DOMAIN); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Suppression complète des données', UNIVGA_TEXT_DOMAIN); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" name="univga_remove_data_on_uninstall" value="1" <?php checked(get_option('univga_remove_data_on_uninstall', false)); ?>>
                            <?php _e('Supprimer TOUTES les données lors de la suppression du plugin', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                        <p class="description">
                            <strong style="color: #d63638;"><?php _e('ATTENTION:', UNIVGA_TEXT_DOMAIN); ?></strong> 
                            <?php _e('Si cette option est activée, TOUTES les données du plugin (organisations, équipes, membres, rapports, analytics IA, etc.) seront définitivement supprimées lors de la désinstallation. Cette action est irréversible !', UNIVGA_TEXT_DOMAIN); ?>
                        </p>
                        <p class="description">
                            <?php _e('Si elle n\'est pas cochée, seuls les caches temporaires seront nettoyés lors de la désinstallation.', UNIVGA_TEXT_DOMAIN); ?>
                        </p>
                    </fieldset>
                </td>
            </tr>
        </table>
        
        <h2><?php _e('System Information', UNIVGA_TEXT_DOMAIN); ?></h2>
        
        <table class="form-table">
            <tr>
                <th scope="row"><?php _e('Plugin Version', UNIVGA_TEXT_DOMAIN); ?></th>
                <td><?php echo UNIVGA_PLUGIN_VERSION; ?></td>
            </tr>
            <tr>
                <th scope="row"><?php _e('WordPress Version', UNIVGA_TEXT_DOMAIN); ?></th>
                <td><?php echo get_bloginfo('version'); ?></td>
            </tr>
            <tr>
                <th scope="row"><?php _e('WooCommerce Version', UNIVGA_TEXT_DOMAIN); ?></th>
                <td><?php echo class_exists('WooCommerce') ? WC()->version : __('Not active', UNIVGA_TEXT_DOMAIN); ?></td>
            </tr>
            <tr>
                <th scope="row"><?php _e('Tutor LMS Version', UNIVGA_TEXT_DOMAIN); ?></th>
                <td><?php echo function_exists('tutor') ? TUTOR_VERSION : __('Not active', UNIVGA_TEXT_DOMAIN); ?></td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" name="submit" class="button-primary" value="<?php _e('Save Settings', UNIVGA_TEXT_DOMAIN); ?>">
        </p>
    </form>
    
    <h2><?php _e('Shortcodes', UNIVGA_TEXT_DOMAIN); ?></h2>
    
    <div class="univga-shortcodes-info">
        <p><strong>[univga_org_dashboard]</strong> - <?php _e('Display organization dashboard for logged-in managers', UNIVGA_TEXT_DOMAIN); ?></p>
        <p><strong>[univga_team_dashboard team_id="123"]</strong> - <?php _e('Display team dashboard for specific team', UNIVGA_TEXT_DOMAIN); ?></p>
    </div>
    
</div>

<style>
.univga-shortcodes-info {
    background: #f9f9f9;
    border: 1px solid #ddd;
    padding: 15px;
    margin-top: 20px;
}
.univga-shortcodes-info p {
    margin: 5px 0;
}
</style>
