<?php

/**
 * Admin interface management
 */
class UNIVGA_Admin {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'handle_admin_actions'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_notices', array($this, 'display_admin_notices'));
        
        // Frontend admin AJAX handlers
        add_action('wp_ajax_univga_update_organization_frontend', array($this, 'ajax_update_organization_frontend'));
        add_action('wp_ajax_univga_save_branding_frontend', array($this, 'ajax_save_branding_frontend'));
        add_action('wp_ajax_univga_get_admin_teams', array($this, 'ajax_get_admin_teams'));
        add_action('wp_ajax_univga_get_admin_members', array($this, 'ajax_get_admin_members'));
        add_action('wp_ajax_univga_get_admin_seat_pools', array($this, 'ajax_get_admin_seat_pools'));
        add_action('wp_ajax_univga_get_admin_settings', array($this, 'ajax_get_admin_settings'));
        add_action('wp_ajax_univga_load_dashboard_metrics', array($this, 'ajax_load_dashboard_metrics'));
        add_action('wp_ajax_univga_export_data', array($this, 'ajax_export_data'));
        add_action('wp_ajax_univga_quick_action', array($this, 'ajax_quick_action'));
        add_action('wp_ajax_univga_bulk_action', array($this, 'ajax_bulk_action'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Ensure administrators have the required capabilities
        $this->ensure_admin_capabilities();
        
        // Always use manage_options for administrators - this is the safest approach
        $admin_cap = 'manage_options';
        
        // Main menu with dashboard (changed slug to avoid conflicts)
        add_menu_page(
            __('Tableau de Bord UNIVGA', UNIVGA_TEXT_DOMAIN),
            __('UNIVGA ENTREPRISES', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-admin-hub',
            array($this, 'display_dashboard_page'),
            'dashicons-dashboard',
            30
        );
        
        // Submenu pages
        add_submenu_page(
            'univga-admin-hub',
            __('Tableau de Bord', UNIVGA_TEXT_DOMAIN),
            __('Tableau de Bord', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-admin-hub',
            array($this, 'display_dashboard_page')
        );
        
        add_submenu_page(
            'univga-admin-hub',
            __('Organisations', UNIVGA_TEXT_DOMAIN),
            __('Organisations', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-organizations',
            array($this, 'display_organizations_page')
        );
        
        add_submenu_page(
            'univga-admin-hub',
            __('Équipes', UNIVGA_TEXT_DOMAIN),
            __('Équipes', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-teams',
            array($this, 'display_teams_page')
        );
        
        add_submenu_page(
            'univga-admin-hub',
            __('Membres', UNIVGA_TEXT_DOMAIN),
            __('Membres', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-members',
            array($this, 'display_members_page')
        );
        
        add_submenu_page(
            'univga-admin-hub',
            __('Pools de Sièges', UNIVGA_TEXT_DOMAIN),
            __('Pools de Sièges', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-pools',
            array($this, 'display_pools_page')
        );
        
        // User Profiles & Permissions - ALL ADMINS can access
        add_submenu_page(
            'univga-admin-hub',
            __('Profils Utilisateurs', UNIVGA_TEXT_DOMAIN),
            __('Profils Utilisateurs', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-profiles',
            array($this, 'display_profiles_page')
        );
        
        // HR Dashboards - ALL ADMINS can access
        add_submenu_page(
            'univga-admin-hub',
            __('Suivi & Reporting RH', UNIVGA_TEXT_DOMAIN),
            __('Reporting RH', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-hr-dashboards',
            array($this, 'display_hr_dashboards_page')
        );
        
        // AI Analytics - ALL ADMINS can access
        add_submenu_page(
            'univga-admin-hub',
            __('Analytics Intelligents', UNIVGA_TEXT_DOMAIN),
            __('Analytics IA', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-ai-analytics',
            array($this, 'display_ai_analytics_page')
        );
        
        add_submenu_page(
            'univga-admin-hub',
            __('Paramètres', UNIVGA_TEXT_DOMAIN),
            __('Paramètres', UNIVGA_TEXT_DOMAIN),
            $admin_cap,
            'univga-settings',
            array($this, 'display_settings_page')
        );
    }
    
    /**
     * Ensure admin capabilities are properly set
     */
    private function ensure_admin_capabilities() {
        // Only run for administrators
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $admin_role = get_role('administrator');
        if ($admin_role) {
            // Add all UNIVGA capabilities to administrator role
            $capabilities = array(
                // Core admin capabilities
                'univga_admin_access',
                
                // Organization management
                'univga_org_create',
                'univga_org_edit',
                'univga_org_delete',
                'univga_org_view',
                'univga_org_manage',
                
                // Team management
                'univga_team_create',
                'univga_team_edit',
                'univga_team_delete',
                'univga_team_view',
                'univga_team_manage',
                'univga_team_assign_members',
                
                // Member management
                'univga_member_invite',
                'univga_member_remove',
                'univga_member_edit',
                'univga_member_view_all',
                'univga_member_view_team',
                
                // Seat pool management
                'univga_seats_create',
                'univga_seats_edit',
                'univga_seats_assign',
                'univga_seats_revoke',
                'univga_seats_view_usage',
                'univga_seats_manage',
                
                // Analytics and reporting
                'univga_analytics_basic',
                'univga_analytics_advanced',
                'univga_reports_generate',
                'univga_reports_export',
                'univga_reports_view_team',
                'univga_reports_view_org',
                'univga_reports_view',
                
                // Learning paths
                'univga_learning_paths_create',
                'univga_learning_paths_assign',
                'univga_learning_paths_manage',
                
                // Certifications
                'univga_cert_create',
                'univga_cert_award',
                'univga_cert_revoke',
                'univga_cert_view_all',
                
                // Bulk operations
                'univga_bulk_import',
                'univga_bulk_enroll',
                'univga_bulk_operations',
                
                // Gamification
                'univga_gamification_manage',
                'univga_badges_create',
                'univga_badges_award',
                'univga_points_adjust',
                
                // Notifications
                'univga_notifications_send',
                'univga_notifications_broadcast',
                'univga_templates_manage',
                
                // Integrations
                'univga_integrations_manage',
                'univga_sso_configure',
                'univga_hr_sync',
                
                // Branding
                'univga_branding_manage',
                'univga_custom_css',
                'univga_custom_domain',
                
                // System settings
                'univga_settings_global',
                'univga_permissions_manage',
                'univga_audit_logs',
                'univga_system_health',
                
                // Internal messaging
                'univga_messaging_send',
                'univga_messaging_moderate',
                'univga_messaging_view_all',
                'univga_messaging_admin'
            );
            
            foreach ($capabilities as $cap) {
                if (!$admin_role->has_cap($cap)) {
                    $admin_role->add_cap($cap);
                }
            }
        }
    }
    
    /**
     * Handle admin actions
     */
    public function handle_admin_actions() {
        if (!isset($_GET['page']) || strpos($_GET['page'], 'univga-') !== 0) {
            return;
        }
        
        // Check admin permissions before handling any actions
        if (!current_user_can('manage_options')) {
            return;
        }
        
        if (!isset($_GET['action'])) {
            return;
        }
        
        $action = sanitize_text_field($_GET['action']);
        
        switch ($action) {
            case 'create_org':
                $this->handle_create_organization();
                break;
            case 'edit_org':
                $this->handle_edit_organization();
                break;
            case 'delete_org':
                $this->handle_delete_organization();
                break;
            case 'create_team':
                $this->handle_create_team();
                break;
            case 'edit_team':
                $this->handle_edit_team();
                break;
            case 'delete_team':
                $this->handle_delete_team();
                break;
            case 'manual_resync':
                $this->handle_manual_resync();
                break;
        }
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook_suffix) {
        if (strpos($hook_suffix, 'univga-') === false) {
            return;
        }
        
        wp_enqueue_style('univga-admin', UNIVGA_PLUGIN_URL . 'admin/css/admin.css', array(), UNIVGA_PLUGIN_VERSION);
        wp_enqueue_script('univga-admin', UNIVGA_PLUGIN_URL . 'admin/js/admin.js', array('jquery'), UNIVGA_PLUGIN_VERSION, true);
        
        wp_localize_script('univga-admin', 'univga_admin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('univga_admin_nonce'),
            'strings' => array(
                'confirm_delete' => __('Are you sure you want to delete this item?', UNIVGA_TEXT_DOMAIN),
                'confirm_resync' => __('This will resync all organization data. Continue?', UNIVGA_TEXT_DOMAIN),
            ),
        ));
    }
    
    /**
     * Display admin notices
     */
    public function display_admin_notices() {
        if (isset($_GET['message'])) {
            $message = sanitize_text_field($_GET['message']);
            $type = isset($_GET['message_type']) ? sanitize_text_field($_GET['message_type']) : 'success';
            
            univga_display_admin_notice($message, $type);
        }
    }
    
    /**
     * Display organizations page
     */
    public function display_organizations_page() {
        // Check admin permissions - ALL ADMINS can access
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-orgs.php';
    }
    
    /**
     * Display dashboard page
     */
    public function display_dashboard_page() {
        // Check admin permissions
        if (!current_user_can('univga_admin_access') && !current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-dashboard.php';
    }
    
    /**
     * Display teams page
     */
    public function display_teams_page() {
        // Check admin permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-teams.php';
    }
    
    /**
     * Display members page
     */
    public function display_members_page() {
        // Check admin permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-members.php';
    }
    
    /**
     * Display pools page
     */
    public function display_pools_page() {
        // Check admin permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-pools.php';
    }
    
    /**
     * Display settings page
     */
    public function display_settings_page() {
        // Check admin permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-settings.php';
    }
    
    /**
     * Display user profiles page
     */
    public function display_profiles_page() {
        // Check admin permissions - ALL ADMINS can access
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-profiles.php';
    }
    
    /**
     * Display HR dashboards page
     */
    public function display_hr_dashboards_page() {
        // Check admin permissions - ALL ADMINS can access
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-hr-dashboards.php';
    }
    
    /**
     * Display AI Analytics page
     */
    public function display_ai_analytics_page() {
        // Check admin permissions - ALL ADMINS can access
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', UNIVGA_TEXT_DOMAIN));
        }
        
        require_once UNIVGA_PLUGIN_DIR . 'admin/views/admin-ai-analytics.php';
    }
    
    /**
     * Handle create organization
     */
    private function handle_create_organization() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'create_org')) {
            wp_die(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'legal_id' => sanitize_text_field($_POST['legal_id']),
            'contact_user_id' => intval($_POST['contact_user_id']),
            'email_domain' => sanitize_text_field($_POST['email_domain']),
            'status' => intval($_POST['status']),
        );
        
        $result = UNIVGA_Orgs::create($data);
        
        if (is_wp_error($result)) {
            $redirect_url = add_query_arg(array(
                'message' => $result->get_error_message(),
                'message_type' => 'error',
            ), univga_get_admin_url('univga-organizations'));
        } else {
            $redirect_url = add_query_arg(array(
                'message' => __('Organization created successfully', UNIVGA_TEXT_DOMAIN),
            ), univga_get_admin_url('univga-organizations'));
        }
        
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Handle edit organization
     */
    private function handle_edit_organization() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'edit_org')) {
            wp_die(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'legal_id' => sanitize_text_field($_POST['legal_id']),
            'contact_user_id' => intval($_POST['contact_user_id']),
            'email_domain' => sanitize_text_field($_POST['email_domain']),
            'status' => intval($_POST['status']),
        );
        
        $result = UNIVGA_Orgs::update($org_id, $data);
        
        if ($result) {
            $redirect_url = add_query_arg(array(
                'message' => __('Organization updated successfully', UNIVGA_TEXT_DOMAIN),
            ), univga_get_admin_url('univga-organizations'));
        } else {
            $redirect_url = add_query_arg(array(
                'message' => __('Failed to update organization', UNIVGA_TEXT_DOMAIN),
                'message_type' => 'error',
            ), univga_get_admin_url('univga-organizations'));
        }
        
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Handle delete organization
     */
    private function handle_delete_organization() {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'delete_org_' . $_GET['org_id'])) {
            wp_die(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_GET['org_id']);
        $result = UNIVGA_Orgs::delete($org_id);
        
        if ($result) {
            $redirect_url = add_query_arg(array(
                'message' => __('Organization deleted successfully', UNIVGA_TEXT_DOMAIN),
            ), univga_get_admin_url('univga-organizations'));
        } else {
            $redirect_url = add_query_arg(array(
                'message' => __('Failed to delete organization', UNIVGA_TEXT_DOMAIN),
                'message_type' => 'error',
            ), univga_get_admin_url('univga-organizations'));
        }
        
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Handle manual resync
     */
    private function handle_manual_resync() {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'manual_resync')) {
            wp_die(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        $result = UNIVGA_Cron::trigger_manual_resync();
        
        if ($result) {
            $redirect_url = add_query_arg(array(
                'message' => __('Manual resync triggered successfully', UNIVGA_TEXT_DOMAIN),
            ), univga_get_admin_url('univga-settings'));
        } else {
            $redirect_url = add_query_arg(array(
                'message' => __('Failed to trigger manual resync', UNIVGA_TEXT_DOMAIN),
                'message_type' => 'error',
            ), univga_get_admin_url('univga-settings'));
        }
        
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * AJAX handler for frontend organization update
     */
    public function ajax_update_organization_frontend() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        $data = array(
            'name' => sanitize_text_field($_POST['name']),
            'legal_id' => sanitize_text_field($_POST['legal_id']),
            'email_domain' => sanitize_text_field($_POST['email_domain']),
            'status' => intval($_POST['status'])
        );
        
        // Update organization
        $result = UNIVGA_Orgs::update($org_id, $data);
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Organization updated successfully', UNIVGA_TEXT_DOMAIN),
                'data' => $data
            ));
        } else {
            wp_send_json_error(__('Failed to update organization', UNIVGA_TEXT_DOMAIN));
        }
    }
    
    /**
     * AJAX handler for frontend branding save
     */
    public function ajax_save_branding_frontend() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        $upload_dir = wp_upload_dir();
        $response_data = array();
        
        // Handle logo upload
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logo_result = $this->handle_file_upload($_FILES['logo'], 'logo');
            if ($logo_result['success']) {
                update_option('univga_org_logo_' . $org_id, $logo_result['url']);
                $response_data['logo_url'] = $logo_result['url'];
            }
        }
        
        // Handle cover upload
        if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
            $cover_result = $this->handle_file_upload($_FILES['cover'], 'cover');
            if ($cover_result['success']) {
                update_option('univga_org_cover_' . $org_id, $cover_result['url']);
                $response_data['cover_url'] = $cover_result['url'];
            }
        }
        
        wp_send_json_success($response_data);
    }
    
    /**
     * Handle file upload for branding
     */
    private function handle_file_upload($file, $type) {
        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }
        
        $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
        if (!in_array($file['type'], $allowed_types)) {
            return array('success' => false, 'error' => __('Invalid file type', UNIVGA_TEXT_DOMAIN));
        }
        
        $upload_overrides = array('test_form' => false);
        $movefile = wp_handle_upload($file, $upload_overrides);
        
        if ($movefile && !isset($movefile['error'])) {
            return array('success' => true, 'url' => $movefile['url']);
        } else {
            return array('success' => false, 'error' => $movefile['error']);
        }
    }
    
    /**
     * AJAX handler for getting admin teams
     */
    public function ajax_get_admin_teams() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        $teams = UNIVGA_Teams::get_by_org($org_id);
        
        ob_start();
        ?>
        <div class="univga-admin-teams-list">
            <?php if (empty($teams)): ?>
                <div class="univga-empty-state">
                    <p><?php _e('No teams found. Create your first team!', UNIVGA_TEXT_DOMAIN); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($teams as $team): ?>
                    <div class="univga-team-card">
                        <div class="univga-team-info">
                            <h4><?php echo esc_html($team->name); ?></h4>
                            <p><?php echo esc_html($team->description ?: __('No description', UNIVGA_TEXT_DOMAIN)); ?></p>
                            <div class="univga-team-stats">
                                <span class="member-count"><?php printf(__('%d members', UNIVGA_TEXT_DOMAIN), $team->member_count ?: 0); ?></span>
                            </div>
                        </div>
                        <div class="univga-team-actions">
                            <button type="button" class="univga-btn univga-btn-secondary" data-action="edit-team" data-team-id="<?php echo $team->id; ?>">
                                <?php _e('Edit', UNIVGA_TEXT_DOMAIN); ?>
                            </button>
                            <button type="button" class="univga-btn univga-btn-danger" data-action="delete-team" data-team-id="<?php echo $team->id; ?>">
                                <?php _e('Delete', UNIVGA_TEXT_DOMAIN); ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php
        
        wp_send_json_success(array('html' => ob_get_clean()));
    }
    
    /**
     * AJAX handler for loading dashboard metrics
     */
    public function ajax_load_dashboard_metrics() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_admin_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('univga_admin_access')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $current_user_id = get_current_user_id();
        $has_financial_access = UNIVGA_User_Profiles::user_has_financial_access($current_user_id);
        
        $metrics = array(
            'organizations' => array(
                'total' => UNIVGA_Orgs::count(),
                'active' => UNIVGA_Orgs::count_by_status(1),
                'pending' => UNIVGA_Orgs::count_by_status(0)
            ),
            'members' => array(
                'total' => UNIVGA_Members::count(),
                'active' => UNIVGA_Members::count_active(),
                'new_this_month' => UNIVGA_Members::count_new_this_month()
            ),
            'seats' => array(
                'total' => UNIVGA_Pools::count_total_seats(),
                'used' => UNIVGA_Pools::count_used_seats(),
                'utilization_rate' => UNIVGA_Pools::get_utilization_rate()
            )
        );
        
        // Add financial metrics if user has access
        if ($has_financial_access) {
            $metrics['financial'] = array(
                'monthly_revenue' => 15420,
                'total_revenue' => 124350,
                'pending_payments' => 3250,
                'subscription_count' => $metrics['organizations']['active']
            );
        }
        
        wp_send_json_success($metrics);
    }
    
    /**
     * AJAX handler for getting admin members
     */
    public function ajax_get_admin_members() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        $members = UNIVGA_Members::get_by_org($org_id);
        
        ob_start();
        ?>
        <div class="univga-admin-members-list">
            <div class="univga-bulk-actions">
                <select id="bulk-action-select">
                    <option value=""><?php _e('Bulk Actions', UNIVGA_TEXT_DOMAIN); ?></option>
                    <option value="remove"><?php _e('Remove Selected', UNIVGA_TEXT_DOMAIN); ?></option>
                    <option value="change_team"><?php _e('Change Team', UNIVGA_TEXT_DOMAIN); ?></option>
                    <option value="export"><?php _e('Export Selected', UNIVGA_TEXT_DOMAIN); ?></option>
                </select>
                <button type="button" class="univga-btn univga-btn-secondary" id="apply-bulk-action">
                    <?php _e('Apply', UNIVGA_TEXT_DOMAIN); ?>
                </button>
            </div>
            
            <?php if (empty($members)): ?>
                <div class="univga-empty-state">
                    <p><?php _e('No members found. Invite your first members!', UNIVGA_TEXT_DOMAIN); ?></p>
                </div>
            <?php else: ?>
                <div class="univga-members-table">
                    <table class="univga-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="select-all-members"></th>
                                <th><?php _e('Member', UNIVGA_TEXT_DOMAIN); ?></th>
                                <th><?php _e('Team', UNIVGA_TEXT_DOMAIN); ?></th>
                                <th><?php _e('Status', UNIVGA_TEXT_DOMAIN); ?></th>
                                <th><?php _e('Joined', UNIVGA_TEXT_DOMAIN); ?></th>
                                <th><?php _e('Actions', UNIVGA_TEXT_DOMAIN); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($members as $member): ?>
                                <tr>
                                    <td><input type="checkbox" class="member-checkbox" value="<?php echo $member->id; ?>"></td>
                                    <td>
                                        <div class="univga-member-info">
                                            <strong><?php echo esc_html($member->display_name); ?></strong>
                                            <br><small><?php echo esc_html($member->email); ?></small>
                                        </div>
                                    </td>
                                    <td><?php echo esc_html($member->team_name ?: __('No team', UNIVGA_TEXT_DOMAIN)); ?></td>
                                    <td>
                                        <span class="univga-status <?php echo $member->status; ?>">
                                            <?php echo ucfirst($member->status); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M j, Y', strtotime($member->created_at)); ?></td>
                                    <td>
                                        <button type="button" class="univga-btn univga-btn-small" data-action="edit-member" data-member-id="<?php echo $member->id; ?>">
                                            <?php _e('Edit', UNIVGA_TEXT_DOMAIN); ?>
                                        </button>
                                        <button type="button" class="univga-btn univga-btn-danger univga-btn-small" data-action="remove-member" data-member-id="<?php echo $member->id; ?>">
                                            <?php _e('Remove', UNIVGA_TEXT_DOMAIN); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        <?php
        
        wp_send_json_success(array('html' => ob_get_clean()));
    }
    
    /**
     * AJAX handler for getting admin seat pools
     */
    public function ajax_get_admin_seat_pools() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        $pools = UNIVGA_Seat_Pools::get_by_org($org_id);
        
        ob_start();
        ?>
        <div class="univga-admin-pools-list">
            <?php if (empty($pools)): ?>
                <div class="univga-empty-state">
                    <p><?php _e('No seat pools found. Create your first seat pool!', UNIVGA_TEXT_DOMAIN); ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($pools as $pool): ?>
                    <div class="univga-pool-card">
                        <div class="univga-pool-info">
                            <h4><?php echo esc_html($pool->name); ?></h4>
                            <div class="univga-pool-stats">
                                <div class="stat">
                                    <span class="label"><?php _e('Total Seats:', UNIVGA_TEXT_DOMAIN); ?></span>
                                    <span class="value"><?php echo $pool->total_seats; ?></span>
                                </div>
                                <div class="stat">
                                    <span class="label"><?php _e('Available:', UNIVGA_TEXT_DOMAIN); ?></span>
                                    <span class="value"><?php echo $pool->available_seats; ?></span>
                                </div>
                                <div class="stat">
                                    <span class="label"><?php _e('Expires:', UNIVGA_TEXT_DOMAIN); ?></span>
                                    <span class="value"><?php echo $pool->expires_at ? date('M j, Y', strtotime($pool->expires_at)) : __('Never', UNIVGA_TEXT_DOMAIN); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="univga-pool-actions">
                            <button type="button" class="univga-btn univga-btn-secondary" data-action="edit-pool" data-pool-id="<?php echo $pool->id; ?>">
                                <?php _e('Edit', UNIVGA_TEXT_DOMAIN); ?>
                            </button>
                            <button type="button" class="univga-btn univga-btn-danger" data-action="delete-pool" data-pool-id="<?php echo $pool->id; ?>">
                                <?php _e('Delete', UNIVGA_TEXT_DOMAIN); ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php
        
        wp_send_json_success(array('html' => ob_get_clean()));
    }
    
    /**
     * AJAX handler for getting admin settings
     */
    public function ajax_get_admin_settings() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'univga_dashboard_nonce')) {
            wp_send_json_error(__('Security check failed', UNIVGA_TEXT_DOMAIN));
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', UNIVGA_TEXT_DOMAIN));
        }
        
        $org_id = intval($_POST['org_id']);
        
        ob_start();
        ?>
        <div class="univga-admin-settings">
            <form id="org-settings-form">
                <div class="univga-settings-section">
                    <h4><?php _e('Learning Management', UNIVGA_TEXT_DOMAIN); ?></h4>
                    <div class="univga-form-group">
                        <label>
                            <input type="checkbox" name="auto_enrollment" value="1" <?php checked(get_option('univga_auto_enrollment_' . $org_id, 0)); ?>>
                            <?php _e('Auto-enroll new members in default courses', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                    </div>
                    <div class="univga-form-group">
                        <label>
                            <input type="checkbox" name="completion_notifications" value="1" <?php checked(get_option('univga_completion_notifications_' . $org_id, 1)); ?>>
                            <?php _e('Send course completion notifications', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                    </div>
                </div>
                
                <div class="univga-settings-section">
                    <h4><?php _e('Access Control', UNIVGA_TEXT_DOMAIN); ?></h4>
                    <div class="univga-form-group">
                        <label>
                            <input type="checkbox" name="require_approval" value="1" <?php checked(get_option('univga_require_approval_' . $org_id, 0)); ?>>
                            <?php _e('Require administrator approval for new members', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                    </div>
                    <div class="univga-form-group">
                        <label>
                            <input type="checkbox" name="restrict_courses" value="1" <?php checked(get_option('univga_restrict_courses_' . $org_id, 0)); ?>>
                            <?php _e('Restrict course access to organization members only', UNIVGA_TEXT_DOMAIN); ?>
                        </label>
                    </div>
                </div>
                
                <div class="univga-settings-section">
                    <h4><?php _e('Notifications', UNIVGA_TEXT_DOMAIN); ?></h4>
                    <div class="univga-form-group">
                        <label for="notification_email"><?php _e('Admin Notification Email', UNIVGA_TEXT_DOMAIN); ?></label>
                        <input type="email" name="notification_email" value="<?php echo esc_attr(get_option('univga_notification_email_' . $org_id, '')); ?>">
                    </div>
                </div>
                
                <div class="univga-form-actions">
                    <button type="submit" class="univga-btn univga-btn-primary">
                        <?php _e('Save Settings', UNIVGA_TEXT_DOMAIN); ?>
                    </button>
                </div>
            </form>
        </div>
        <?php
        
        wp_send_json_success(array('html' => ob_get_clean()));
    }
}
