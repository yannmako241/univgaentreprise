<?php
/**
 * Enhanced Direct Download Handler with Error Checking
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file = __DIR__ . '/univga-plugin-error-fix.zip';

// Debug info
echo "<!-- Debug Info:\n";
echo "Looking for file: $file\n";
echo "File exists: " . (file_exists($file) ? 'YES' : 'NO') . "\n";
echo "File readable: " . (is_readable($file) ? 'YES' : 'NO') . "\n";
if (file_exists($file)) {
    echo "File size: " . filesize($file) . " bytes\n";
}
echo "-->\n";

// Check if file exists
if (!file_exists($file)) {
    http_response_code(404);
    die('File not found: ' . $file);
}

if (!is_readable($file)) {
    http_response_code(403);
    die('File not readable: ' . $file);
}

// Clear any output buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Set headers for download
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="univga-plugin-error-fix.zip"');
header('Content-Length: ' . filesize($file));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output the file
if (readfile($file) === false) {
    http_response_code(500);
    die('Error reading file');
}
exit;
?>