<?php
/**
 * Direct download handler for UNIVGA plugin
 */

$file = 'univga-plugin-final-safe.zip';

// Check if file exists
if (!file_exists($file)) {
    http_response_code(404);
    die('File not found');
}

// Set headers for download
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . basename($file) . '"');
header('Content-Length: ' . filesize($file));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');

// Output the file
readfile($file);
exit;
?>